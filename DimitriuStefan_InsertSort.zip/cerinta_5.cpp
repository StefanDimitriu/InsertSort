#include<iostream>

using namespace std;

int main()
{
    int i=0,j,n,alesul,v[100];
    cout<<"introdu numarul de elemente= ";
    cin>>n;
    cout<<"introdu elementele : ";


    while(i<n){
        cout<<"v["<<i<<"]=";
        cin>>v[i];
        i++;
    }
    i=1;
    while(i<n){
       alesul=v[i];
       j=i-1;
       while((alesul<v[j])&&(j>=0))
        {
            v[j+1]=v[j];
            j=j-1;
        }

        v[j+1]=alesul;
        i++;
    }

    cout<<"Elementele sortate sunt : ";
    i=0;
    while(i<n){
        cout<<v[i]<<" ";
        i++;
    }
    return 0;
}
